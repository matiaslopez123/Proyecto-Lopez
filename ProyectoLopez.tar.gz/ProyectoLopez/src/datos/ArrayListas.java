/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package datos;

/**
 *
 * @author matias
 */
public abstract class ArrayListas {
    private static Lista[] listas = new Lista[5];
    public static Lista ganador;
    public static Lista cantVotos8;
    

   
    
    /**
     * Esta funcion agrega una nueva lista de candidatos al array
     * @param lista
     * @return 
     */
    public static boolean addLista(Lista lista){
        for (int i=0; i<listas.length; i++){
            if (listas[i]==null){
                listas[i]=lista;
                return true;
            }
        }
        return false;
    } 
    
    /**
     * Devuelve el array de listas
     */
    public static Lista[] getLista() {
        return listas;
                
    }
}
