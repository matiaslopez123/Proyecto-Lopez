package datos;




public class Lista {
    
    String lista;
    int curso;
    int cantVotos=0;
    
    public Lista(){
        lista="";
        curso=0;
            
    }

    public int getCantVotos() {
        return cantVotos;
    }

    public void setCantVotos(int cantVotos) {
        this.cantVotos = cantVotos;
    }
    
    public void addVotos(int votos){
        this.cantVotos += votos;
    }

    public String getLista() {
        return lista;
    }

    public void setLista(String lista) {
        this.lista = lista;
    }

    public int getCurso() {
        return curso;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }
    
    public String toString(){
        return  lista +   "     - Curso: " + curso + " año " + " - Votos:"  + cantVotos;
    }
    
    
}
