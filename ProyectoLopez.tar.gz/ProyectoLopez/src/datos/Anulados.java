/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package datos;

/**
 *
 * @author matias
 */
public class Anulados {
    String VotosA;
   
    int cantVotos=0;
    public boolean CantVotos;
    public boolean votosA;
    
    public Anulados(){
        VotosA="";
        cantVotos=0;
}

    public String getVotosA() {
        return VotosA;
    }

    public void setVotosA(String VotosA) {
        this.VotosA = VotosA;
    }

    public int getCantVotos() {
        return cantVotos;
    }

    public void setCantVotos(int cantVotos) {
        this.cantVotos = cantVotos;
    }
    
    public void addVoto(int num) {
        this.cantVotos = this.cantVotos + num;
    }
    
    
    
}