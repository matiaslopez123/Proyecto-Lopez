/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package datos;

/**
 *
 * @author matias
 */
public class Blanco {
    
    String VotosB;
   
    int cantVotos=0;
    
    public Blanco(){
        VotosB="";
        cantVotos=0;
               
}

    public String getVotosB() {
        return VotosB;
    }

    public void setVotosB(String VotosB) {
        this.VotosB = VotosB;
    }

    public int getCantVotos() {
        return cantVotos;
    }

    public void setCantVotos(int cantVotos) {
        this.cantVotos = cantVotos;
    }
    
    
    
    
}
