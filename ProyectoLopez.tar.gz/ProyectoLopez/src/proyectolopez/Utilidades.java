/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package proyectolopez;

/**
 *
 * @author matias
 */
public class Utilidades {
    
    int i;
    int j=0;
    private String total;
    
    public String sumarVotos(int totalHastaAhora){
        
        
        j=totalHastaAhora;
        
        j += i;
        total = "" + j;
        return total;
    }

    public int getI() {
        return i;
    }
    public void setI(int i) {
        this.i = i;
    }
}
